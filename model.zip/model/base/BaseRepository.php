<?php 
class BaseRepository {
	protected $error;

	function getError() {
		return $this->error;
	}
}
?>